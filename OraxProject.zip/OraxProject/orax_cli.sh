#!/data/data/com.termux/files/usr/bin/bash
ORAX_HOME="$HOME/OraxProject"
case "$1" in
    --menu|-m|"")
        bash "$ORAX_HOME/orax.sh"
        ;;
    --help|-h)
        echo ""
        echo "  OraxProject CLI"
        echo "  Usage:"
        echo "    orax --menu           Buka menu"
        echo "    oai --{pertanyaan}    Tanya AI"
        echo "    apikey --{key}        Set Groq key"
        echo ""
        ;;
    *)
        echo "  Command tidak dikenal: $1"
        ;;
esac
