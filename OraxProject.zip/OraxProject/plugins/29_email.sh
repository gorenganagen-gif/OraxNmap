# NAME: Email Tools
while true; do
    clear
    echo -e "${GRAY}┌─ Email Tools ───────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Validate Email${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}MX Lookup${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}SPF Check${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  Email: " e; clear; curl -s "https://api.hackertarget.com/emailvalidate/?q=$e"; read -p "  $(t press_any)..." ;;
        2) if ! command -v dig >/dev/null; then show_install "dnsutils" "pkg install dnsutils -y"; continue; fi
           read -p "  Domain: " d; clear; dig +short MX "$d"; read -p "  $(t press_any)..." ;;
        3) read -p "  Domain: " d; clear; dig TXT "$d" +short | grep -i spf; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
