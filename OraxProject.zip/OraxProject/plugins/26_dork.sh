# NAME: Google Dork
while true; do
    clear
    echo -e "${GRAY}┌─ Google Dork Gen ───────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Find Login${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Find Config${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}Find Admin${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}Find Backup${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[5]${NC} ${GRAY}Find SQL Errors${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    [ "$c" = "0" ] && return
    read -p "  Target domain: " d
    clear
    case "$c" in
        1) echo "  https://www.google.com/search?q=site:$d+inurl:login" ;;
        2) echo "  https://www.google.com/search?q=site:$d+filetype:env OR filetype:conf" ;;
        3) echo "  https://www.google.com/search?q=site:$d+inurl:admin" ;;
        4) echo "  https://www.google.com/search?q=site:$d+filetype:bak OR filetype:backup" ;;
        5) echo "  https://www.google.com/search?q=site:$d+intext:\"SQL syntax\"" ;;
    esac
    read -p "  $(t press_any)..." ;;
done
