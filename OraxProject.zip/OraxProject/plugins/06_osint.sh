# NAME: OSINT Tools
while true; do
    clear
    echo -e "${GRAY}┌─ OSINT Tools ───────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Username Search${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Email Lookup${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}IP Info${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}Domain Info${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[5]${NC} ${GRAY}GitHub User${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[6]${NC} ${GRAY}IP Location${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[7]${NC} ${GRAY}My IP Address${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  Username: " u; clear
           for s in "github.com/" "twitter.com/" "instagram.com/" "reddit.com/user/"; do
             code=$(curl -s -o /dev/null -w "%{http_code}" "https://$s$u" 2>/dev/null)
             [ "$code" = "200" ] && echo "  [+] https://$s$u"; done
           read -p "  $(t press_any)..." ;;
        2) read -p "  Email: " e; clear; curl -s "https://api.hackertarget.com/emailvalidate/?q=$e"; read -p "  $(t press_any)..." ;;
        3) read -p "  IP/Domain: " t; clear; curl -s "https://ipinfo.io/$t/json"; read -p "  $(t press_any)..." ;;
        4) read -p "  Domain: " d; clear; curl -s "https://api.hackertarget.com/whois/?q=$d" | head -40; read -p "  $(t press_any)..." ;;
        5) read -p "  GitHub: " u; clear; curl -s "https://api.github.com/users/$u" | grep -E '"login"|"name"|"bio"|"public_repos"|"followers"'; read -p "  $(t press_any)..." ;;
        6) read -p "  IP: " ip; clear; curl -s "http://ip-api.com/json/$ip"; read -p "  $(t press_any)..." ;;
        7) clear; curl -s "https://ipinfo.io/json"; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
