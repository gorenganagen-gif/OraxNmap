# NAME: SSL Tools
if ! command -v openssl >/dev/null; then show_install "openssl" "pkg install openssl -y"; return; fi
while true; do
    clear
    echo -e "${GRAY}┌─ SSL Tools ─────────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Cert Info${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Cert Expiry${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}Cert Chain${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}Protocol Check${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  Domain: " d; clear; echo | openssl s_client -connect "$d:443" -servername "$d" 2>/dev/null | openssl x509 -noout -text | head -30; read -p "  $(t press_any)..." ;;
        2) read -p "  Domain: " d; clear; echo | openssl s_client -connect "$d:443" -servername "$d" 2>/dev/null | openssl x509 -noout -dates; read -p "  $(t press_any)..." ;;
        3) read -p "  Domain: " d; clear; echo | openssl s_client -connect "$d:443" -servername "$d" -showcerts 2>/dev/null | grep -E "s:|i:"; read -p "  $(t press_any)..." ;;
        4) read -p "  Domain: " d; clear; echo | openssl s_client -connect "$d:443" -servername "$d" 2>&1 | grep -E "Protocol|Cipher"; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
