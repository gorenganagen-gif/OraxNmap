# NAME: Network Tools
while true; do
    clear
    echo -e "${GRAY}┌─ Network Tools ─────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Ping Test${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Port Check${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}Banner Grab${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}DNS Resolve${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[5]${NC} ${GRAY}HTTP Status${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[6]${NC} ${GRAY}Ping Sweep${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  Host: " h; clear; ping -c 5 "$h"; read -p "  $(t press_any)..." ;;
        2) read -p "  Host: " h; read -p "  Port: " p; clear
           (echo > /dev/tcp/$h/$p) 2>/dev/null && echo "  [+] OPEN" || echo "  [-] CLOSED"; read -p "  $(t press_any)..." ;;
        3) read -p "  Host: " h; read -p "  Port [80]: " p; p=${p:-80}; clear
           exec 3<>/dev/tcp/$h/$p && echo -e "GET / HTTP/1.0\r\n\r\n" >&3 && head -5 <&3; read -p "  $(t press_any)..." ;;
        4) read -p "  Domain: " d; clear; nslookup "$d" 2>/dev/null || getent hosts "$d"; read -p "  $(t press_any)..." ;;
        5) read -p "  URL: " u; clear; curl -s -o /dev/null -w "  HTTP %{http_code}\n" "$u"; read -p "  $(t press_any)..." ;;
        6) detect_network; clear
           for i in $(seq 1 254); do (ping -c 1 -W 1 $(echo "$SUBNET" | sed "s/0\/24/$i/") >/dev/null 2>&1 && echo "  $(echo "$SUBNET" | sed "s/0\/24/$i/") UP") & done; wait
           read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
