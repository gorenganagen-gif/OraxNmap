# NAME: URL Tools
while true; do
    clear
    echo -e "${GRAY}┌─ URL Tools ─────────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Shorten URL${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Expand URL${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}URL Status${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}URL Info${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  URL: " u; clear; curl -s "https://tinyurl.com/api-create.php?url=$u"; echo ""; read -p "  $(t press_any)..." ;;
        2) read -p "  URL: " u; clear; curl -sIL "$u" | grep -i "^location:" | tail -1; read -p "  $(t press_any)..." ;;
        3) read -p "  URL: " u; clear; curl -s -o /dev/null -w "  Status: %{http_code}\n" "$u"; read -p "  $(t press_any)..." ;;
        4) read -p "  URL: " u; clear; curl -s -o /dev/null -w "  IP: %{remote_ip}\n  Port: %{remote_port}\n  Time: %{time_total}s\n" "$u"; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
