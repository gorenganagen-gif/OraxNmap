# NAME: Bug Bounty Tools
while true; do
    clear
    echo -e "${GRAY}┌─ Bug Bounty Tools ──────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Recon Subdomains${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Find JS Files${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}Find Parameters${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}Check CORS${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[5]${NC} ${GRAY}Check Headers${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  Domain: " d; clear; curl -s "https://crt.sh/?q=%25.$d&output=json" | grep -oP '"name_value":"\K[^"]+' | sort -u | head -30; read -p "  $(t press_any)..." ;;
        2) read -p "  URL: " u; clear; curl -s "$u" | grep -oP 'src="\K[^"]+\.js' | sort -u; read -p "  $(t press_any)..." ;;
        3) read -p "  URL: " u; clear; curl -s "$u" | grep -oP '\?[a-zA-Z_]+=' | sort -u; read -p "  $(t press_any)..." ;;
        4) read -p "  URL: " u; clear; curl -sI -H "Origin: https://evil.com" "$u" | grep -iE "access-control"; read -p "  $(t press_any)..." ;;
        5) read -p "  URL: " u; clear; curl -sI "$u" | grep -iE "server|x-powered|x-frame"; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
