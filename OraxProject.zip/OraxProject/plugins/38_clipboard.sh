# NAME: Clipboard Tools
while true; do
    clear
    echo -e "${GRAY}┌─ Clipboard Tools ───────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Copy${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Paste${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    if ! command -v termux-clipboard-set >/dev/null; then show_install "termux-api" "pkg install termux-api -y"; continue; fi
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  Text: " t; echo -n "$t" | termux-clipboard-set; echo "  [+] Copied"; read -p "  $(t press_any)..." ;;
        2) clear; echo "  $(termux-clipboard-get)"; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
