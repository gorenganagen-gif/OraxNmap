# NAME: SMS/Call Tools
while true; do
    clear
    echo -e "${GRAY}┌─ SMS/Call Tools ────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Send SMS${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Read SMS${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}Make Call${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}Call Log${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[5]${NC} ${GRAY}Contacts${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    if ! command -v termux-sms-send >/dev/null; then show_install "termux-api" "pkg install termux-api -y"; continue; fi
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  Number: " n; read -p "  Message: " m; clear; termux-sms-send -n "$n" "$m"; read -p "  $(t press_any)..." ;;
        2) clear; termux-sms-list -l 10; read -p "  $(t press_any)..." ;;
        3) read -p "  Number: " n; clear; termux-telephony-call "$n"; read -p "  $(t press_any)..." ;;
        4) clear; termux-call-log -l 10; read -p "  $(t press_any)..." ;;
        5) clear; termux-contact-list | head -30; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
