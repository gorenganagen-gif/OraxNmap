# NAME: Wayback Machine
while true; do
    clear
    echo -e "${GRAY}┌─ Wayback Machine ───────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}List Snapshots${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Find Old URLs${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}First Snapshot${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  URL: " u; clear; curl -s "http://archive.org/wayback/available?url=$u"; read -p "  $(t press_any)..." ;;
        2) read -p "  Domain: " d; clear; curl -s "http://web.archive.org/cdx/search/cdx?url=$d*&output=text&fl=original&collapse=urlkey&limit=50"; read -p "  $(t press_any)..." ;;
        3) read -p "  Domain: " d; clear; curl -s "http://web.archive.org/cdx/search/cdx?url=$d&output=text&fl=timestamp&limit=1"; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
