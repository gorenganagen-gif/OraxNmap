# NAME: Hash Cracker
while true; do
    clear
    echo -e "${GRAY}┌─ Hash Cracker ──────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Identify Hash${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}MD5 Crack${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}SHA1 Crack${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}SHA256 Crack${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[5]${NC} ${GRAY}Wordlist Gen${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  Hash: " h; clear; l=${#h}
           case $l in 32) echo "  MD5/NTLM";; 40) echo "  SHA1";; 64) echo "  SHA256";; 96) echo "  SHA384";; 128) echo "  SHA512";; *) echo "  Unknown: $l";; esac
           read -p "  $(t press_any)..." ;;
        2) read -p "  MD5: " h; clear
           for w in password 123456 admin root test qwerty letmein; do
             [ "$(echo -n "$w" | md5sum | awk '{print $1}')" = "$h" ] && echo "  [+] $w" && break; done
           read -p "  $(t press_any)..." ;;
        3) read -p "  SHA1: " h; clear
           for w in password 123456 admin root test; do
             [ "$(echo -n "$w" | sha1sum | awk '{print $1}')" = "$h" ] && echo "  [+] $w" && break; done
           read -p "  $(t press_any)..." ;;
        4) read -p "  SHA256: " h; clear
           for w in password 123456 admin root; do
             [ "$(echo -n "$w" | sha256sum | awk '{print $1}')" = "$h" ] && echo "  [+] $w" && break; done
           read -p "  $(t press_any)..." ;;
        5) read -p "  Save [wordlist.txt]: " f; f=${f:-wordlist.txt}
           read -p "  Min [4]: " min; min=${min:-4}; read -p "  Max [6]: " max; max=${max:-6}
           clear; python3 -c "
import itertools, string
chars = string.ascii_lowercase + string.digits
with open('$f','w') as fp:
    for l in range($min,$max+1):
        for c in itertools.product(chars, repeat=l): fp.write(''.join(c)+'\n')
print('  [+] Saved: $f')"
           read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
