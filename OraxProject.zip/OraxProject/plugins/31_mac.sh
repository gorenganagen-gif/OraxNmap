# NAME: MAC Lookup
while true; do
    clear
    echo -e "${GRAY}┌─ MAC Lookup ────────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}MAC Vendor${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}My MAC${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}ARP Table${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  MAC: " m; clear; curl -s "https://api.macvendors.com/$m"; echo ""; read -p "  $(t press_any)..." ;;
        2) clear; ip link show wlan0 2>/dev/null | grep link/ether || ifconfig wlan0 2>/dev/null | grep ether; read -p "  $(t press_any)..." ;;
        3) clear; cat /proc/net/arp; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
