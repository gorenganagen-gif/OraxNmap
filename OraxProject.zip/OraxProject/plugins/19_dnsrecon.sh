# NAME: DNS Recon
if ! command -v dig >/dev/null; then show_install "dnsutils" "pkg install dnsutils -y"; return; fi
while true; do
    clear
    echo -e "${GRAY}┌─ DNS Recon ─────────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Zone Transfer${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Nameserver${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}SPF Record${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}DMARC Record${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  Domain: " d; clear; ns=$(dig +short NS "$d" | head -1); dig AXFR "$d" @$ns; read -p "  $(t press_any)..." ;;
        2) read -p "  Domain: " d; clear; dig NS "$d" +short; read -p "  $(t press_any)..." ;;
        3) read -p "  Domain: " d; clear; dig TXT "$d" +short | grep -i spf; read -p "  $(t press_any)..." ;;
        4) read -p "  Domain: " d; clear; dig TXT "_dmarc.$d" +short; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
