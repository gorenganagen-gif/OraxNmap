# NAME: Port Scanner
if ! command -v nmap >/dev/null 2>&1; then show_install "nmap" "pkg install nmap -y"; return; fi
while true; do
    clear
    echo -e "${GRAY}┌─ Port Scanner ──────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Top 100 Ports${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Top 1000 Ports${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}All Ports${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}Common Ports${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[5]${NC} ${GRAY}Custom Range${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  IP: " ip; clear; nmap -F "$ip"; read -p "  $(t press_any)..." ;;
        2) read -p "  IP: " ip; clear; nmap --top-ports 1000 "$ip"; read -p "  $(t press_any)..." ;;
        3) read -p "  IP: " ip; clear; nmap -p- "$ip"; read -p "  $(t press_any)..." ;;
        4) read -p "  IP: " ip; clear; nmap -p 21,22,23,25,53,80,110,143,443,445,3306,3389,8080 "$ip"; read -p "  $(t press_any)..." ;;
        5) read -p "  IP: " ip; read -p "  Range: " r; clear; nmap -p "$r" "$ip"; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
