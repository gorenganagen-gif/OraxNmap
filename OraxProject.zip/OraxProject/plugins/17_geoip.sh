# NAME: GeoIP Lookup
while true; do
    clear
    echo -e "${GRAY}┌─ GeoIP Lookup ──────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}My IP Info${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Lookup IP${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}Lookup Domain${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}My Public IP${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) clear; curl -s "http://ip-api.com/json/"; read -p "  $(t press_any)..." ;;
        2) read -p "  IP: " ip; clear; curl -s "http://ip-api.com/json/$ip"; read -p "  $(t press_any)..." ;;
        3) read -p "  Domain: " d; clear; curl -s "http://ip-api.com/json/$d"; read -p "  $(t press_any)..." ;;
        4) clear; curl -s ifconfig.me; echo ""; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
