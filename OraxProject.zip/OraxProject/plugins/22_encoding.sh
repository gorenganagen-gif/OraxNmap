# NAME: Encoding Tools
while true; do
    clear
    echo -e "${GRAY}┌─ Encoding Tools ────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}URL Encode${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}URL Decode${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}HTML Encode${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}HTML Decode${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[5]${NC} ${GRAY}Unicode Encode${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  Text: " t; clear; python3 -c "import urllib.parse; print(urllib.parse.quote('$t'))" 2>/dev/null; read -p "  $(t press_any)..." ;;
        2) read -p "  Text: " t; clear; python3 -c "import urllib.parse; print(urllib.parse.unquote('$t'))" 2>/dev/null; read -p "  $(t press_any)..." ;;
        3) read -p "  Text: " t; clear; python3 -c "import html; print(html.escape('$t'))" 2>/dev/null; read -p "  $(t press_any)..." ;;
        4) read -p "  Text: " t; clear; python3 -c "import html; print(html.unescape('$t'))" 2>/dev/null; read -p "  $(t press_any)..." ;;
        5) read -p "  Text: " t; clear; python3 -c "print(''.join('\\\\u{:04x}'.format(ord(c)) for c in '$t'))" 2>/dev/null; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
