# NAME: VPN/Proxy Check
while true; do
    clear
    echo -e "${GRAY}┌─ VPN/Proxy Check ───────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}My IP Info${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}VPN Check${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}Tor Check${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) clear; curl -s "http://ip-api.com/json/?fields=status,country,city,isp,org,as,query,proxy,hosting"; read -p "  $(t press_any)..." ;;
        2) clear; curl -s "http://ip-api.com/json/?fields=proxy,hosting"; read -p "  $(t press_any)..." ;;
        3) clear; curl -s "https://check.torproject.org/api/ip"; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
