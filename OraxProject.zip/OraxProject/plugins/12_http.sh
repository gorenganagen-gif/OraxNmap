# NAME: HTTP Tools
while true; do
    clear
    echo -e "${GRAY}┌─ HTTP Tools ────────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}GET Request${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}POST Request${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}Follow Redirects${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}Response Time${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[5]${NC} ${GRAY}Download File${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[6]${NC} ${GRAY}User Agent Test${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  URL: " u; clear; curl -s "$u" | head -50; read -p "  $(t press_any)..." ;;
        2) read -p "  URL: " u; read -p "  Data: " d; clear; curl -s -X POST -d "$d" "$u"; read -p "  $(t press_any)..." ;;
        3) read -p "  URL: " u; clear; curl -sL "$u" | head -30; read -p "  $(t press_any)..." ;;
        4) read -p "  URL: " u; clear; curl -o /dev/null -s -w "  Time: %{time_total}s\n" "$u"; read -p "  $(t press_any)..." ;;
        5) read -p "  URL: " u; read -p "  Save: " f; clear; curl -o "$f" "$u" && echo "  [+] Saved"; read -p "  $(t press_any)..." ;;
        6) read -p "  URL: " u; clear; curl -s -A "Mozilla/5.0 (Android 13)" "$u" | head -20; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
