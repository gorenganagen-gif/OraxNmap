# NAME: JSON Tools
while true; do
    clear
    echo -e "${GRAY}┌─ JSON Tools ────────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Format JSON${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Validate JSON${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}Minify JSON${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  JSON: " j; clear; echo "$j" | python3 -m json.tool 2>/dev/null || echo "  Invalid"; read -p "  $(t press_any)..." ;;
        2) read -p "  JSON: " j; clear; echo "$j" | python3 -m json.tool >/dev/null 2>&1 && echo "  [+] Valid" || echo "  [X] Invalid"; read -p "  $(t press_any)..." ;;
        3) read -p "  JSON: " j; clear; echo "$j" | python3 -c "import sys,json;print(json.dumps(json.load(sys.stdin),separators=(',',':')))" 2>/dev/null; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
