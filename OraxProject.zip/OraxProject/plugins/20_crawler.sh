# NAME: Web Crawler
while true; do
    clear
    echo -e "${GRAY}┌─ Web Crawler ───────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Extract Links${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Extract Emails${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}Extract Images${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}Extract JS Files${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  URL: " u; clear; curl -s "$u" | grep -oP 'href="\K[^"]+' | sort -u | head -30; read -p "  $(t press_any)..." ;;
        2) read -p "  URL: " u; clear; curl -s "$u" | grep -oE "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,}" | sort -u; read -p "  $(t press_any)..." ;;
        3) read -p "  URL: " u; clear; curl -s "$u" | grep -oP 'src="\K[^"]+' | grep -iE "\.(jpg|png|gif|webp)" | head -20; read -p "  $(t press_any)..." ;;
        4) read -p "  URL: " u; clear; curl -s "$u" | grep -oP 'src="\K[^"]+\.js' | sort -u; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
