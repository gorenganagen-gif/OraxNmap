# NAME: Sniffer Tools
while true; do
    clear
    echo -e "${GRAY}┌─ Sniffer Tools ─────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Tcpdump Basic${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Capture HTTP${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}Capture DNS${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}Capture ARP${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    echo -e "  ${DIM}[!] Butuh root${NC}"
    read -p "  $(t choose): " c
    [ "$c" = "0" ] && return
    if [ "$(id -u)" -ne 0 ]; then echo "  [X] Butuh root!"; sleep 2; continue; fi
    if ! command -v tcpdump >/dev/null; then show_install "tcpdump" "pkg install tcpdump -y"; continue; fi
    case "$c" in
        1) clear; tcpdump -i wlan0 -c 20 ;;
        2) clear; tcpdump -i wlan0 -A 'tcp port 80' -c 10 ;;
        3) clear; tcpdump -i wlan0 'udp port 53' -c 10 ;;
        4) clear; tcpdump -i wlan0 arp -c 10 ;;
    esac
done
