# NAME: GitHub Tools
while true; do
    clear
    echo -e "${GRAY}┌─ GitHub Tools ──────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}User Info${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}User Repos${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}Search Repo${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}Repo Info${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  Username: " u; clear; curl -s "https://api.github.com/users/$u" | grep -E '"login"|"name"|"bio"|"public_repos"|"followers"'; read -p "  $(t press_any)..." ;;
        2) read -p "  Username: " u; clear; curl -s "https://api.github.com/users/$u/repos?per_page=20" | grep '"name"'; read -p "  $(t press_any)..." ;;
        3) read -p "  Keyword: " k; clear; curl -s "https://api.github.com/search/repositories?q=$k&per_page=10" | grep -E '"full_name"|"description"'; read -p "  $(t press_any)..." ;;
        4) read -p "  Owner/Repo: " r; clear; curl -s "https://api.github.com/repos/$r" | grep -E '"name"|"description"|"language"'; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
