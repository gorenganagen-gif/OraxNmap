# NAME: Terminal Utils
while true; do
    clear
    echo -e "${GRAY}┌─ Terminal Utils ────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}System Info${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Disk Usage${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}Memory${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}Processes${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[5]${NC} ${GRAY}Network Stats${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[6]${NC} ${GRAY}Uptime${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) clear; uname -a; echo ""; getprop ro.product.model 2>/dev/null; read -p "  $(t press_any)..." ;;
        2) clear; df -h; read -p "  $(t press_any)..." ;;
        3) clear; free -h 2>/dev/null || cat /proc/meminfo | head -5; read -p "  $(t press_any)..." ;;
        4) clear; ps aux 2>/dev/null | head -30; read -p "  $(t press_any)..." ;;
        5) clear; cat /proc/net/dev; read -p "  $(t press_any)..." ;;
        6) clear; uptime; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
