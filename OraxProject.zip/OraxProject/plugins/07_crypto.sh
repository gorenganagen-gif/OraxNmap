# NAME: Crypto Tools
while true; do
    clear
    echo -e "${GRAY}┌─ Crypto Tools ──────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Base64 Encode${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Base64 Decode${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}MD5 Hash${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}SHA1 Hash${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[5]${NC} ${GRAY}SHA256 Hash${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[6]${NC} ${GRAY}ROT13${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[7]${NC} ${GRAY}URL Encode${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[8]${NC} ${GRAY}Hex Encode${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[9]${NC} ${GRAY}Hex Decode${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  Text: " t; clear; echo "$t" | base64; read -p "  $(t press_any)..." ;;
        2) read -p "  Base64: " t; clear; echo "$t" | base64 -d 2>/dev/null; echo ""; read -p "  $(t press_any)..." ;;
        3) read -p "  Text: " t; clear; echo -n "$t" | md5sum; read -p "  $(t press_any)..." ;;
        4) read -p "  Text: " t; clear; echo -n "$t" | sha1sum; read -p "  $(t press_any)..." ;;
        5) read -p "  Text: " t; clear; echo -n "$t" | sha256sum; read -p "  $(t press_any)..." ;;
        6) read -p "  Text: " t; clear; echo "$t" | tr 'A-Za-z' 'N-ZA-Mn-za-m'; read -p "  $(t press_any)..." ;;
        7) read -p "  Text: " t; clear; python3 -c "import urllib.parse; print(urllib.parse.quote('$t'))" 2>/dev/null; read -p "  $(t press_any)..." ;;
        8) read -p "  Text: " t; clear; echo -n "$t" | xxd -p; read -p "  $(t press_any)..." ;;
        9) read -p "  Hex: " t; clear; echo "$t" | xxd -r -p; echo ""; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
