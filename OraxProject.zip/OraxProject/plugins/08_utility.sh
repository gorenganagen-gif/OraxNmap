# NAME: Utility Tools
while true; do
    clear
    echo -e "${GRAY}┌─ Utility Tools ─────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Password Generator${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}UUID Generator${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}QR Code Generator${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}File Hash Check${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[5]${NC} ${GRAY}Text to Binary${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  Length [16]: " l; l=${l:-16}; clear
           echo "  $(cat /dev/urandom | tr -dc 'A-Za-z0-9!@#$%^&*' | head -c $l)"; read -p "  $(t press_any)..." ;;
        2) clear; echo "  $(cat /proc/sys/kernel/random/uuid)"; read -p "  $(t press_any)..." ;;
        3) if ! command -v qrencode >/dev/null; then show_install "qrencode" "pkg install qrencode -y"; continue; fi
           read -p "  Text: " t; clear; qrencode -t ANSI "$t"; read -p "  $(t press_any)..." ;;
        4) read -p "  File: " f; clear; md5sum "$f" 2>/dev/null; sha256sum "$f" 2>/dev/null; read -p "  $(t press_any)..." ;;
        5) read -p "  Text: " t; clear; echo -n "$t" | xxd -b | head -5; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
