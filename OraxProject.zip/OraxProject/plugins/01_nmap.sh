# NAME: Nmap Scanner
if ! command -v nmap >/dev/null 2>&1; then show_install "nmap" "pkg install nmap -y"; return; fi
while true; do
    clear; detect_network; show_info
    echo -e "${GRAY}┌─ Nmap Scanner ──────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Ping Sweep${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Quick Scan${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}Full Port Scan${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}Service Detect${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[5]${NC} ${GRAY}OS Detection${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[6]${NC} ${GRAY}Aggressive Scan${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[7]${NC} ${GRAY}Vulnerability Scan${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[8]${NC} ${GRAY}UDP Scan${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[9]${NC} ${GRAY}HTTP Probe${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[10]${NC} ${GRAY}Vendor Lookup${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) clear; nmap -sn "$SUBNET" 2>/dev/null | grep -E "Nmap scan|MAC"; read -p "  $(t press_any)..." ;;
        2) read -p "  IP [$GATEWAY]: " ip; ip=${ip:-$GATEWAY}; clear; nmap -F "$ip"; read -p "  $(t press_any)..." ;;
        3) read -p "  IP [$GATEWAY]: " ip; ip=${ip:-$GATEWAY}; clear; nmap -p- "$ip"; read -p "  $(t press_any)..." ;;
        4) read -p "  IP [$GATEWAY]: " ip; ip=${ip:-$GATEWAY}; clear; nmap -sV "$ip"; read -p "  $(t press_any)..." ;;
        5) read -p "  IP [$GATEWAY]: " ip; ip=${ip:-$GATEWAY}; clear; nmap -O --osscan-guess "$ip" 2>/dev/null || nmap -sV "$ip"; read -p "  $(t press_any)..." ;;
        6) read -p "  IP [$GATEWAY]: " ip; ip=${ip:-$GATEWAY}; clear; nmap -A "$ip"; read -p "  $(t press_any)..." ;;
        7) read -p "  IP [$GATEWAY]: " ip; ip=${ip:-$GATEWAY}; clear; nmap --script vuln "$ip"; read -p "  $(t press_any)..." ;;
        8) read -p "  IP [$GATEWAY]: " ip; ip=${ip:-$GATEWAY}; clear; nmap -sU --top-ports 50 "$ip"; read -p "  $(t press_any)..." ;;
        9) read -p "  IP [$GATEWAY]: " ip; ip=${ip:-$GATEWAY}; clear; nmap -p 80,443,8080 --script http-title "$ip"; read -p "  $(t press_any)..." ;;
        10) clear; nmap -sn "$SUBNET" 2>/dev/null | grep -E "Nmap scan|MAC"; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
