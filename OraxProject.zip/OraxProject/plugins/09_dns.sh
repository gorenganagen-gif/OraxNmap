# NAME: DNS Tools
if ! command -v dig >/dev/null; then show_install "dnsutils" "pkg install dnsutils -y"; return; fi
while true; do
    clear
    echo -e "${GRAY}┌─ DNS Tools ─────────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}A Record${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}MX Record${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}TXT Record${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}NS Record${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[5]${NC} ${GRAY}All Records${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[6]${NC} ${GRAY}Reverse DNS${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  Domain: " d; clear; dig +short A "$d"; read -p "  $(t press_any)..." ;;
        2) read -p "  Domain: " d; clear; dig +short MX "$d"; read -p "  $(t press_any)..." ;;
        3) read -p "  Domain: " d; clear; dig +short TXT "$d"; read -p "  $(t press_any)..." ;;
        4) read -p "  Domain: " d; clear; dig +short NS "$d"; read -p "  $(t press_any)..." ;;
        5) read -p "  Domain: " d; clear; dig ANY "$d" +noall +answer; read -p "  $(t press_any)..." ;;
        6) read -p "  IP: " ip; clear; dig -x "$ip" +short; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
