# NAME: Screenshot Tools
while true; do
    clear
    echo -e "${GRAY}┌─ Screenshot Tools ──────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Take Screenshot${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}OCR Image${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) if ! command -v termux-screenshot >/dev/null; then show_install "termux-api" "pkg install termux-api -y"; continue; fi
           clear; termux-screenshot; echo "  [+] Saved"; read -p "  $(t press_any)..." ;;
        2) if ! command -v tesseract >/dev/null; then show_install "tesseract" "pkg install tesseract -y"; continue; fi
           read -p "  Image: " p; clear; tesseract "$p" stdout; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
