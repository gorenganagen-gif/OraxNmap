# NAME: WiFi Tools
while true; do
    clear
    echo -e "${GRAY}┌─ WiFi Tools ────────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}WiFi Info${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Connected Network${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}ARP Table${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}Ping Gateway${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[5]${NC} ${GRAY}Traceroute${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[6]${NC} ${GRAY}Speed Test${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[7]${NC} ${GRAY}WiFi Scan (root)${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) clear; ifconfig 2>/dev/null || ip addr; read -p "  $(t press_any)..." ;;
        2) clear; termux-wifi-connectioninfo 2>/dev/null || echo "  pkg install termux-api"; read -p "  $(t press_any)..." ;;
        3) clear; cat /proc/net/arp; read -p "  $(t press_any)..." ;;
        4) detect_network; clear; ping -c 4 "$GATEWAY"; read -p "  $(t press_any)..." ;;
        5) if ! command -v traceroute >/dev/null; then show_install "traceroute" "pkg install traceroute -y"; continue; fi
           read -p "  Target [8.8.8.8]: " tgt; tgt=${tgt:-8.8.8.8}; clear; traceroute "$tgt"; read -p "  $(t press_any)..." ;;
        6) read -p "  URL: " url; clear; curl -o /dev/null -s -w "  DNS: %{time_namelookup}s\n  Connect: %{time_connect}s\n  Total: %{time_total}s\n" "$url"; read -p "  $(t press_any)..." ;;
        7) if [ "$(id -u)" -ne 0 ]; then echo "  [X] Butuh root!"; sleep 2; continue; fi
           clear; iw dev wlan0 scan 2>/dev/null | grep -E "SSID|signal" | head -30; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
