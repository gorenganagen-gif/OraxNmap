# NAME: Subdomain Enum
while true; do
    clear
    echo -e "${GRAY}┌─ Subdomain Enum ────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Quick Enum${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Deep Enum${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}Cert Search${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  Domain: " d; clear
           for s in www mail ftp admin api dev test blog shop forum cdn static; do
             r=$(getent hosts "$s.$d" 2>/dev/null | awk '{print $1}')
             [ -n "$r" ] && echo "  [+] $s.$d → $r"; done
           read -p "  $(t press_any)..." ;;
        2) read -p "  Domain: " d; clear
           for s in www mail ftp admin api dev test blog shop forum cdn static app m mobile secure vpn portal support docs git wiki img; do
             r=$(getent hosts "$s.$d" 2>/dev/null | awk '{print $1}')
             [ -n "$r" ] && echo "  [+] $s.$d → $r"; done
           read -p "  $(t press_any)..." ;;
        3) read -p "  Domain: " d; clear
           curl -s "https://crt.sh/?q=%25.$d&output=json" | grep -oP '"name_value":"\K[^"]+' | sort -u | head -30
           read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
