# NAME: Web Security
while true; do
    clear
    echo -e "${GRAY}┌─ Web Security ──────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}HTTP Headers${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}SSL/TLS Info${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}robots.txt${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}Subdomain Enum${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[5]${NC} ${GRAY}Directory Buster${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[6]${NC} ${GRAY}CMS Detect${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[7]${NC} ${GRAY}WHOIS Lookup${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[8]${NC} ${GRAY}DNS Lookup${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[9]${NC} ${GRAY}Reverse IP${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[10]${NC} ${GRAY}HTTP Methods${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[11]${NC} ${GRAY}Security Headers${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) if ! command -v curl >/dev/null; then show_install "curl" "pkg install curl -y"; continue; fi
           read -p "  URL: " url; clear; curl -sI "$url"; read -p "  $(t press_any)..." ;;
        2) read -p "  Domain: " d; clear; echo | openssl s_client -connect "$d:443" -servername "$d" 2>/dev/null | openssl x509 -noout -text | head -30; read -p "  $(t press_any)..." ;;
        3) read -p "  URL: " url; clear; curl -s "$url/robots.txt" | head -50; read -p "  $(t press_any)..." ;;
        4) if ! command -v dig >/dev/null; then show_install "dnsutils" "pkg install dnsutils -y"; continue; fi
           read -p "  Domain: " d; clear
           for sub in www mail ftp admin api dev test blog shop forum; do
             r=$(dig +short "$sub.$d" 2>/dev/null); [ -n "$r" ] && echo "  $sub.$d → $r"; done
           read -p "  $(t press_any)..." ;;
        5) read -p "  URL: " url; clear
           for dir in admin login upload images css js api backup config .git .env wp-admin phpmyadmin; do
             code=$(curl -s -o /dev/null -w "%{http_code}" "$url/$dir" 2>/dev/null)
             [ "$code" != "404" ] && [ -n "$code" ] && echo "  [$code] $url/$dir"; done
           read -p "  $(t press_any)..." ;;
        6) read -p "  URL: " url; clear; src=$(curl -s "$url" 2>/dev/null)
           echo "$src" | grep -qi "wp-content" && echo "  [+] WordPress"
           echo "$src" | grep -qi "joomla" && echo "  [+] Joomla"
           echo "$src" | grep -qi "drupal" && echo "  [+] Drupal"
           read -p "  $(t press_any)..." ;;
        7) if ! command -v whois >/dev/null; then show_install "whois" "pkg install whois -y"; continue; fi
           read -p "  Domain/IP: " d; clear; whois "$d" | head -50; read -p "  $(t press_any)..." ;;
        8) if ! command -v nslookup >/dev/null; then show_install "dnsutils" "pkg install dnsutils -y"; continue; fi
           read -p "  Domain: " d; clear; nslookup "$d"; read -p "  $(t press_any)..." ;;
        9) read -p "  IP: " ip; clear; curl -s "https://api.hackertarget.com/reverseiplookup/?q=$ip"; read -p "  $(t press_any)..." ;;
        10) read -p "  URL: " url; clear; curl -sX OPTIONS -i "$url" | head -20; read -p "  $(t press_any)..." ;;
        11) read -p "  URL: " url; clear; curl -sI "$url" | grep -iE "strict|frame|content-security|referrer"; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
