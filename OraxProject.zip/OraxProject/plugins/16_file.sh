# NAME: File Analysis
while true; do
    clear
    echo -e "${GRAY}┌─ File Analysis ─────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}File Info${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}File Hash${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}File Type${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}Strings${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[5]${NC} ${GRAY}Hex Dump${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  Path: " f; clear; ls -lh "$f"; read -p "  $(t press_any)..." ;;
        2) read -p "  Path: " f; clear; md5sum "$f" 2>/dev/null; sha256sum "$f" 2>/dev/null; read -p "  $(t press_any)..." ;;
        3) if ! command -v file >/dev/null; then show_install "file" "pkg install file -y"; continue; fi
           read -p "  Path: " f; clear; file "$f"; read -p "  $(t press_any)..." ;;
        4) read -p "  Path: " f; clear; strings "$f" 2>/dev/null | head -30; read -p "  $(t press_any)..." ;;
        5) read -p "  Path: " f; clear; xxd "$f" 2>/dev/null | head -20; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
