# NAME: Whois Tools
if ! command -v whois >/dev/null; then show_install "whois" "pkg install whois -y"; return; fi
while true; do
    clear
    echo -e "${GRAY}┌─ Whois Tools ───────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Domain Whois${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}IP Whois${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}Registrar Info${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  Domain: " d; clear; whois "$d" | head -60; read -p "  $(t press_any)..." ;;
        2) read -p "  IP: " ip; clear; whois "$ip" | head -60; read -p "  $(t press_any)..." ;;
        3) read -p "  Domain: " d; clear; whois "$d" | grep -iE "registrar|created|expires|updated"; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
