# NAME: Password Tools
while true; do
    clear
    echo -e "${GRAY}┌─ Password Tools ────────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}Generate Strong${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}Generate PIN${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}Strength Check${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}Passphrase${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  Length [20]: " l; l=${l:-20}; clear
           for i in 1 2 3; do echo "  $(cat /dev/urandom | tr -dc 'A-Za-z0-9!@#$%^&*' | head -c $l)"; done
           read -p "  $(t press_any)..." ;;
        2) read -p "  Length [6]: " l; l=${l:-6}; clear; echo "  $(cat /dev/urandom | tr -dc '0-9' | head -c $l)"; read -p "  $(t press_any)..." ;;
        3) read -p "  Password: " p; clear; score=0
           [ ${#p} -ge 8 ] && ((score++)); [ ${#p} -ge 12 ] && ((score++))
           echo "$p" | grep -q '[A-Z]' && ((score++)); echo "$p" | grep -q '[a-z]' && ((score++))
           echo "$p" | grep -q '[0-9]' && ((score++)); echo "$p" | grep -q '[^A-Za-z0-9]' && ((score++))
           echo "  Score: $score/6"; read -p "  $(t press_any)..." ;;
        4) clear; words=(apple river mountain cloud tiger ocean star moon fire stone)
           echo -n "  "; for i in 1 2 3 4; do echo -n "${words[$RANDOM % ${#words[@]}]}-"; done; echo ""
           read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
