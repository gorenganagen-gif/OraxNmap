# NAME: Web Vuln Scanner
while true; do
    clear
    echo -e "${GRAY}┌─ Web Vuln Scanner ──────────────────┐${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[1]${NC} ${GRAY}XSS Test${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[2]${NC} ${GRAY}LFI Test${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[3]${NC} ${GRAY}Open Redirect${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[4]${NC} ${GRAY}CSRF Check${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[5]${NC} ${GRAY}CORS Check${NC}"
    echo -e "${GRAY}│${NC} ${WHITE}[0]${NC} ${GRAY}Back${NC}"
    echo -e "${GRAY}└─────────────────────────────────────┘${NC}"
    read -p "  $(t choose): " c
    case "$c" in
        1) read -p "  URL: " u; clear
           for p in "<script>alert(1)</script>" "\"><script>alert(1)</script>"; do
             r=$(curl -s "$u$p" | grep -i "alert(1)" | head -1); [ -n "$r" ] && echo "  [+] XSS: $p"; done
           read -p "  $(t press_any)..." ;;
        2) read -p "  URL: " u; clear
           for p in "../../etc/passwd" "/etc/passwd"; do
             r=$(curl -s "$u$p" | grep "root:"); [ -n "$r" ] && echo "  [+] LFI: $p"; done
           read -p "  $(t press_any)..." ;;
        3) read -p "  URL: " u; clear; curl -sI "$u?url=https://evil.com" | grep -i location; read -p "  $(t press_any)..." ;;
        4) read -p "  URL: " u; clear; curl -s "$u" | grep -iE "csrf|token" | head -5; read -p "  $(t press_any)..." ;;
        5) read -p "  URL: " u; clear; curl -sI -H "Origin: https://evil.com" "$u" | grep -i "access-control"; read -p "  $(t press_any)..." ;;
        0) return ;;
    esac
done
