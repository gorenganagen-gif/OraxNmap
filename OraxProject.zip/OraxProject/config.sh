#!/data/data/com.termux/files/usr/bin/bash
# ==========================================
#   OraxProject - Config
# ==========================================

# Simpan bahasa yang dipilih
LANG_FILE="$HOME/OraxProject/.lang"
if [ -f "$LANG_FILE" ]; then
    ORAX_LANG=$(cat "$LANG_FILE")
else
    ORAX_LANG="eng"
fi

# ===== FUNGSI BAHASA =====
t() {
    local key="$1"
    if [ "$ORAX_LANG" = "ind" ]; then
        case "$key" in
            welcome)      echo "Selamat Datang di" ;;
            access)       echo "Akses" ;;
            skip_login)   echo "Skip Login? Y/n" ;;
            username)     echo "Username Random" ;;
            password)     echo "Password Random" ;;
            select_lang)  echo "Pilih Bahasa Indo/Eng" ;;
            navigating)   echo "Navigasi" ;;
            selected)     echo "Pilih" ;;
            exit)         echo "Keluar" ;;
            back)         echo "Kembali ke menu" ;;
            press_any)    echo "Tekan tombol apa saja untuk kembali" ;;
            not_installed) echo "BELUM TERINSTALL" ;;
            install_cmd)  echo "Jalankan command berikut untuk install" ;;
            copy_paste)   echo "Copy paste command di atas, lalu jalankan ulang script" ;;
            access_menu)  echo "Akses Menu" ;;
            *)            echo "$key" ;;
        esac
    else
        case "$key" in
            welcome)      echo "Welcome To" ;;
            access)       echo "Access" ;;
            skip_login)   echo "Skip Login? Y/n" ;;
            username)     echo "Username Random" ;;
            password)     echo "Password Random" ;;
            select_lang)  echo "Select Language Indo/Eng" ;;
            navigating)   echo "Navigate" ;;
            selected)     echo "Select" ;;
            exit)         echo "Exit" ;;
            back)         echo "Back to menu" ;;
            press_any)    echo "Press any key to return" ;;
            not_installed) echo "NOT INSTALLED" ;;
            install_cmd)  echo "Run this command to install" ;;
            copy_paste)   echo "Copy paste command above, then rerun script" ;;
            access_menu)  echo "Access Menu" ;;
            *)            echo "$key" ;;
        esac
    fi
}

# ===== CEK TOOL =====
check_tool() {
    local tool="$1"
    local install_cmd="$2"
    if ! command -v "$tool" >/dev/null 2>&1; then
        return 1
    fi
    return 0
}

# ===== TAMPILKAN COMMAND INSTALL =====
show_install() {
    local tool="$1"
    local cmd="$2"
    clear
    echo ""
    echo "  [X] $tool $(t not_installed)"
    echo ""
    echo "  $(t install_cmd):"
    echo ""
    echo "     $cmd"
    echo ""
    echo "  $(t copy_paste)"
    echo ""
    read -p "  $(t press_any)..."
}
