#!/data/data/com.termux/files/usr/bin/bash
ORAX_HOME="$HOME/OraxProject"
AI_DIR="$ORAX_HOME/.ai"
AI_HISTORY="$AI_DIR/history.json"
AI_KEY_FILE="$AI_DIR/apikey.txt"
AI_PROMPT_FILE="$AI_DIR/system_prompt.txt"

WHITE='\033[1;37m'
GRAY='\033[0;37m'
DIM='\033[2;37m'
NC='\033[0m'
GREEN='\033[1;32m'
RED='\033[1;31m'
YELLOW='\033[1;33m'

mkdir -p "$AI_DIR"

# ============================================================
# SYSTEM PROMPT (di file terpisah biar aman dari quote)
# ============================================================
write_prompt() {
    cat << 'PROMPTEND' > "$AI_PROMPT_FILE"
Kamu adalah OraxAI dengan KONTROL PENUH ke Termux Android.

KEMAMPUAN KAMU:
- Baca file (read_file)
- Lihat isi folder (list_dir)
- Buat/tulis file baru (write_file)
- Buat folder baru (make_dir)
- Hapus file/folder (delete)
- Jalankan command shell (run_cmd)
- Cek info file (file_info)

CARA PAKAI TOOL - gunakan tag [tool] dan [/tool] seperti ini:

[tool]
TOOL: read_file
PATH: /path/file
[/tool]

[tool]
TOOL: list_dir
PATH: /path/dir
[/tool]

[tool]
TOOL: write_file
PATH: /path/file
CONTENT:
isi file disini
[/tool]

[tool]
TOOL: make_dir
PATH: /path/dir
[/tool]

[tool]
TOOL: delete
PATH: /path
[/tool]

[tool]
TOOL: run_cmd
CMD: command yang mau dijalankan
[/tool]

[tool]
TOOL: file_info
PATH: /path
[/tool]

ATURAN:
- JELASKAN dulu apa yang mau kamu lakukan
- Baru keluarkan blok [tool] ... [/tool]
- Boleh keluarkan banyak tool sekaligus
- Jawab santai dalam Bahasa Indonesia
- Konfirmasi dulu kalau mau hapus file penting
- Untuk lihat live coding, pakai read_file berkali-kali atau run_cmd
PROMPTEND
}

write_prompt

# ============================================================
# API KEY
# ============================================================
set_apikey() {
    local key="$1"
    if [ -z "$key" ]; then
        echo -e "  ${RED}[X] API key kosong!${NC}"
        return 1
    fi
    echo "$key" > "$AI_KEY_FILE"
    chmod 600 "$AI_KEY_FILE"
    echo -e "  ${GREEN}[OK] API key tersimpan${NC}"
}

get_apikey() {
    if [ -f "$AI_KEY_FILE" ]; then
        cat "$AI_KEY_FILE"
    else
        echo ""
    fi
}

check_apikey() {
    local key
    key=$(get_apikey)
    if [ -z "$key" ]; then
        echo -e "  ${RED}[X] API key belum diset!${NC}"
        echo -e "  ${YELLOW}[i] Set: apikey --{api_key}${NC}"
        echo -e "  ${DIM}Gratis: https://console.groq.com/keys${NC}"
        return 1
    fi
    return 0
}

# ============================================================
# JSON ESCAPE
# ============================================================
json_escape() {
    local s="$1"
    s="${s//\\/\\\\}"
    s="${s//\"/\\\"}"
    s="${s//$'\n'/\\n}"
    s="${s//$'\r'/\\r}"
    s="${s//$'\t'/\\t}"
    printf '%s' "$s"
}

# ============================================================
# EXECUTE TOOL
# ============================================================
execute_tool() {
    local tool="$1"
    local args="$2"
    case "$tool" in
        read_file)
            local path
            path=$(echo "$args" | grep "^PATH:" | sed 's/^PATH:[[:space:]]*//')
            path=$(eval echo "$path")
            if [ -f "$path" ]; then
                echo -e "${DIM}  +-- Reading: $path${NC}"
                head -100 "$path"
                echo -e "${DIM}  +-- EOF${NC}"
            else
                echo -e "  ${RED}[X] File tidak ada: $path${NC}"
            fi
            ;;
        list_dir)
            local path
            path=$(echo "$args" | grep "^PATH:" | sed 's/^PATH:[[:space:]]*//')
            path=$(eval echo "$path")
            if [ -d "$path" ]; then
                echo -e "${DIM}  +-- Dir: $path${NC}"
                ls -la "$path" | tail -n +2 | awk '{printf "  | %-10s %-8s %s\n", $1, $5, $NF}'
                echo -e "${DIM}  +--${NC}"
            else
                echo -e "  ${RED}[X] Folder tidak ada: $path${NC}"
            fi
            ;;
        write_file)
            local path
            path=$(echo "$args" | grep "^PATH:" | sed 's/^PATH:[[:space:]]*//')
            path=$(eval echo "$path")
            local content
            content=$(echo "$args" | sed -n '/^CONTENT:/,$p' | tail -n +2)
            mkdir -p "$(dirname "$path")"
            echo "$content" > "$path"
            echo -e "  ${GREEN}[OK] File dibuat: $path${NC}"
            ;;
        make_dir)
            local path
            path=$(echo "$args" | grep "^PATH:" | sed 's/^PATH:[[:space:]]*//')
            path=$(eval echo "$path")
            mkdir -p "$path"
            echo -e "  ${GREEN}[OK] Folder dibuat: $path${NC}"
            ;;
        delete)
            local path
            path=$(echo "$args" | grep "^PATH:" | sed 's/^PATH:[[:space:]]*//')
            path=$(eval echo "$path")
            rm -rf "$path"
            echo -e "  ${YELLOW}[!] Dihapus: $path${NC}"
            ;;
        run_cmd)
            local cmd
            cmd=$(echo "$args" | grep "^CMD:" | sed 's/^CMD:[[:space:]]*//')
            echo -e "${DIM}  +-- Running: $cmd${NC}"
            eval "$cmd" 2>&1 | head -50
            echo -e "${DIM}  +-- Done${NC}"
            ;;
        file_info)
            local path
            path=$(echo "$args" | grep "^PATH:" | sed 's/^PATH:[[:space:]]*//')
            path=$(eval echo "$path")
            if [ -e "$path" ]; then
                echo -e "${DIM}  +-- Info: $path${NC}"
                file "$path" 2>/dev/null
                ls -lh "$path"
                echo -e "${DIM}  +--${NC}"
            else
                echo -e "  ${RED}[X] Tidak ada: $path${NC}"
            fi
            ;;
        *)
            echo -e "  ${RED}[X] Tool tidak dikenal: $tool${NC}"
            ;;
    esac
}

# ============================================================
# PROCESS TOOLS
# ============================================================
process_tools() {
    local response="$1"
    local capturing=0
    local tool_block=""
    local line
    while IFS= read -r line; do
        if [ "$line" = "[tool]" ]; then
            capturing=1
            tool_block=""
        elif [ "$line" = "[/tool]" ] && [ "$capturing" = "1" ]; then
            capturing=0
            local tool
            tool=$(echo "$tool_block" | grep "^TOOL:" | sed 's/^TOOL:[[:space:]]*//')
            local args
            args=$(echo "$tool_block" | grep -v "^TOOL:")
            if [ -n "$tool" ]; then
                echo ""
                execute_tool "$tool" "$args"
            fi
        elif [ "$capturing" = "1" ]; then
            tool_block="${tool_block}${line}"$'\n'
        fi
    done <<< "$response"
}

# ============================================================
# CALL API
# ============================================================
call_groq_api() {
    local user_msg="$1"
    local key
    key=$(get_apikey)
    local model="openai/gpt-oss-120b"
    local sys_raw
    sys_raw=$(cat "$AI_PROMPT_FILE")
    local sys_escaped
    sys_escaped=$(json_escape "$sys_raw")
    local user_escaped
    user_escaped=$(json_escape "$user_msg")
    
    local history_json=""
    if [ -f "$AI_HISTORY" ] && [ -s "$AI_HISTORY" ]; then
        history_json=$(cat "$AI_HISTORY")
    fi
    
    local messages="[{\"role\":\"system\",\"content\":\"$sys_escaped\"}"
    if [ -n "$history_json" ] && [ "$history_json" != "[]" ]; then
        local hist_inner
        hist_inner="${history_json#[}"
        hist_inner="${hist_inner%]}"
        messages="${messages},${hist_inner}"
    fi
    messages="${messages},{\"role\":\"user\",\"content\":\"$user_escaped\"}]"
    
    local payload="{\"model\":\"$model\",\"messages\":$messages,\"temperature\":0.7,\"max_tokens\":4096}"
    
    curl -s https://api.groq.com/openai/v1/chat/completions \
        -H "Authorization: Bearer $key" \
        -H "Content-Type: application/json" \
        -d "$payload" > "$AI_DIR/last_response.json"
}

# ============================================================
# EXTRACT CONTENT
# ============================================================
extract_content() {
    local json="$1"
    echo "$json" | grep -oP '"content"\s*:\s*"\K[^"]*(?:\\.[^"]*)*' | head -1 | \
        sed 's/\\n/\n/g; s/\\"/"/g; s/\\t/\t/g; s/\\\\/\\/g'
}

# ============================================================
# SAVE HISTORY
# ============================================================
save_to_history() {
    local role="$1"
    local content="$2"
    local escaped
    escaped=$(json_escape "$content")
    local entry="{\"role\":\"$role\",\"content\":\"$escaped\"}"
    if [ -f "$AI_HISTORY" ] && [ -s "$AI_HISTORY" ]; then
        local current
        current=$(cat "$AI_HISTORY")
        if [ "${current:0:1}" = "[" ] && [ "${current: -1}" = "]" ] && [ "$current" != "[]" ]; then
            current="${current%]}"
            echo "${current},${entry}]" > "$AI_HISTORY"
        else
            echo "[${entry}]" > "$AI_HISTORY"
        fi
    else
        echo "[${entry}]" > "$AI_HISTORY"
    fi
}

# ============================================================
# ASK GROQ
# ============================================================
ask_groq() {
    local question="$1"
    if ! check_apikey; then return 1; fi
    echo ""
    echo -e "${DIM}[*] Menghubungi Groq...${NC}"
    call_groq_api "$question"
    local response
    response=$(cat "$AI_DIR/last_response.json")
    local ai_text
    ai_text=$(extract_content "$response")
    if echo "$response" | grep -q '"error"'; then
        local err
        err=$(echo "$response" | grep -oP '"message"\s*:\s*"\K[^"]*' | head -1)
        echo -e "  ${RED}[X] Error: $err${NC}"
        return 1
    fi
    if [ -z "$ai_text" ]; then
        echo -e "  ${RED}[X] Tidak dapat respon${NC}"
        echo -e "  ${DIM}$(echo "$response" | head -c 200)${NC}"
        return 1
    fi
    save_to_history "user" "$question"
    save_to_history "assistant" "$ai_text"
    echo ""
    echo -e "${WHITE}--- OraxAI ------------------------------------${NC}"
    while IFS= read -r line; do
        echo -e "  $line"
    done <<< "$ai_text"
    echo -e "${WHITE}-----------------------------------------------${NC}"
    if echo "$ai_text" | grep -q '\[tool\]'; then
        process_tools "$ai_text"
    fi
}

# ============================================================
# INTERACTIVE MODE
# ============================================================
run_interactive() {
    echo -e "  ${WHITE}OraxAI Interactive${NC}"
    echo -e "  ${DIM}Ketik 'exit' untuk keluar${NC}"
    echo ""
    local user_input
    while true; do
        read -p "  You: " user_input
        if [ "$user_input" = "exit" ]; then
            break
        fi
        if [ -z "$user_input" ]; then
            continue
        fi
        ask_groq "$user_input"
        echo ""
    done
}

# ============================================================
# MAIN
# ============================================================
case "$1" in
    --apikey|-k)
        set_apikey "$2"
        ;;
    --reset)
        rm -f "$AI_HISTORY"
        echo -e "  ${GREEN}[OK] History direset${NC}"
        ;;
    --history)
        if [ -f "$AI_HISTORY" ]; then
            cat "$AI_HISTORY"
        else
            echo "  Kosong"
        fi
        ;;
    --model)
        if [ -n "$2" ]; then
            sed -i "s|^local model=.*|local model=\"$2\"|" "$ORAX_HOME/ai.sh"
            echo -e "  ${GREEN}[OK] Model diganti: $2${NC}"
        else
            grep "^local model=" "$ORAX_HOME/ai.sh" | head -1
        fi
        ;;
    --help|-h)
        echo ""
        echo "  OraxAI - Groq Assistant"
        echo "  Usage:"
        echo "    oai --{pertanyaan}     Tanya AI"
        echo "    apikey --{api_key}     Set Groq key"
        echo "    oai --reset            Reset history"
        echo "    oai --model {nama}     Ganti model"
        echo ""
        echo "  API key: https://console.groq.com/keys"
        echo ""
        ;;
    *)
        q="$*"
        while [ "${q:0:1}" = "-" ]; do
            q="${q:1}"
        done
        if [ -n "$q" ]; then
            ask_groq "$q"
        else
            run_interactive
        fi
        ;;
esac
