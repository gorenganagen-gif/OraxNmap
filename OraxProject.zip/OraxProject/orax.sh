#!/data/data/com.termux/files/usr/bin/bash

ORAX_HOME="$HOME/OraxProject"
PLUGIN_DIR="$ORAX_HOME/plugins"
RESULT_DIR="$ORAX_HOME/results"
LANG_FILE="$ORAX_HOME/.lang"

WHITE='\033[1;37m'
GRAY='\033[0;37m'
DIM='\033[2;37m'
NC='\033[0m'
HL_BG='\033[48;5;240m'
HL_FG='\033[1;97m'
HL_RESET='\033[0m'

source "$ORAX_HOME/config.sh"

# ===== ASCII BANNER =====
print_banner() {
    echo -e "${DIM}"
    echo '  ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ...'
    echo '       ......-##+=++++++=+*#+:.. . . .. .. .. .. .'
    echo '  ..... .-**#%@@@%###%%@@@@@%#***:.++:...... .. . ..... ..... ..... ..... ....... .......'
    echo ' ...+%%%+--=++***++=-...=#@@@@#%**%=.. ... ... .. . .... .... ... .... ..'
    echo '  ...=@#+**=.-**##*##++-:+#*:..=%@=#%%+...... .... ..... ..... ..... ..... ..... ....'
    echo '....#%#=...-%+%%####++@**....+#:==#@#@*%. ... .... ... ..... ...... ..... ..'
    echo '  .%*....:%*%%##%#+%@@@##. .. .-@##+#@#%. ... ... .... .. ... .. .. .. .'
    echo '  ..... .@@@@*%%*#@@@@@%#.... .*-##%=*%... . ..... ..... . ... ..... ..... ..... ....'
    echo '       . .:#+%@%*@@@@@@%#.. .==-%-.*+.. . ... .. ... .. .. .'
    echo ' ........-%%@@@#%@@@@@@%%...*#%=*-... ...... ..... ..... ....... ...... ..... ....... .....'
    echo '     ..**=+*#*@@*@@@@@%+*..+%****. ... .. .... . ... .. .. .'
    echo '  ....#**%@#%##%@%#@@#%**..%++*#=..... ..... .... ..... ..... .... .... .... ....'
    echo ' ....#=####%@%##+@@#@%%%%%#-**-*.. ....... ... . ........... ... .. ... .... ....'
    echo '  ..*=*####%@@%#%++@@@%%@=-*@=-%-...-#@@@@#-.. ...-#@#:..+@@*.....-*@@@@@*:......-#@@+....:#@@=..'
    echo '...#+%@@@@@@@%%+@*%%%@#:+%***@*#:@@@@@@@@@@@@:..=@@@@@@-@@@@@@::@@@@@@@@@@@@#...%@@@@@@-.-@@@@@@-..'
    echo '  :%+@#@=+@%@@@@@#@@@%-=@@+*@%@*@@@@@@@@@@@@@@@=.+@@@@@#%@@@@@@+#@@@@@@@@@@@@@@@..@@@@@@@%.*@@@@@@=.'
    echo '  ==@@%@**%*=+-+#@@@-=@@%@@@=@@*@@@@@@@@##@@@@@@@::@@@@@@@@@@@@@=:@@@@@%@@@@@@@@=.#@@@@@@@+@@@@@@@.'
    echo ' .:##@@@%@##*+%*=***+@@@*@@@##@#@@@@@@*..*@@@@@@*.@@@@@@@+%@@@%.....:==-:@@@@@@+..+@@@@@@@@@@@@*.'
    echo '  ..#%%@@@%@#*@@%*++#@%%#@@@@%*@@@@@@@=..-@@@@@@%.%@@@@@%..:=....*@@@@@@@@@@@@@+....#@@@@@@@@*....'
    echo ' . .=**@@@@@+@@**@@@@@%#%=#%%%+@@@@@@@=..-@@@@@@%.@@@@@@#... ..:@@@@@@@##@@@@@@+ ..:%@@@@@@@@@+.. .'
    echo '  ...#%=@@@@#@-=@@@@@@#%@--.#%@#@@@@@@+..*@@@@@@+.@@@@@@%.. ..*@@@@@@..=@@@@@@=..#@@@@@@@@@@@@@:.'
    echo ' ....%#@+*@@@-+%@@@%@@#%%-%....+@@@@@@@=+@@@@@@@.-@@@@@@@.. ..#@@@@@@:.*@@@@@@+.%@@@@@@*@@@@@@@@-'
    echo '    .@*@@@%%:=@@%@@#@%##%*%=.. #@@@@@@@@@@@@@@=.=@@@@@@@+.. *@@@@@@@@@@@@@@@%-@@@@@@@.*@@@@@@@*'
    echo '  ..=##@@@@=-#%%%%%-@=%:##=#. ..+@@@@@@@@@@@%:..:@@@@@@@=.. .@@@@@@@@%:@@@@@@.@@@@@@#..#@@@@@@='
    echo '  .+++@%@@#:+@%%@*#-@=@+##%++#.. ...-*@@@@@#=... ...+%@%+:.. ... .-#@@@#-..*@@#-...+%@%+. ..=%@@*:.'
    echo ' .+-*%%#@@:+#@%@+#+%@@#@##*#=+. .... ....... .... ...... ..... ............. .............'
    echo '.-%+%##%@@#*@@@*##=@@@*@@%%%*#.. . .. .. ... ..... ..... ... ...'
    echo '==##%%@@@@@@@%#%%=@@@@@*@@@@++........ ... .... ..... ..... ..... ...... .... ....'
    echo '.-#%%%@@@@@@@@%*##+#%%%%+..... ..... ... ... ...... .... .... .... .... ....'
    echo '    ... ..---:. .. ... .. .. . . ..... ... .. . . . .... .'
    echo -e "${NC}"
}

line_sep() { echo "--------------------------------------------------------------------------------"; }

# ===== LOGIN =====
login_screen() {
    clear
    total_menu=$(ls "$PLUGIN_DIR"/*.sh 2>/dev/null | wc -l)
    print_banner
    echo ""
    echo "------------------------------------>> OraxProject <<----------------------------------------------"
    echo -e " Welcome To ${WHITE}OraxProject${NC}"
    echo -e " - - - Access {$total_menu} Menus"
    line_sep
    echo ""
    read -p " Skip Login? Y/n : " skip
    
    if [[ ! "$skip" =~ ^[Yy]$ ]]; then
        USER_RAND="user_$(cat /dev/urandom | tr -dc 'a-z0-9' | head -c 6)"
        PASS_RAND="$(cat /dev/urandom | tr -dc 'A-Za-z0-9' | head -c 10)"
        clear
        print_banner
        echo ""
        echo "------------------------------------>> Login <<----------------------------------------------"
        echo -e " Username Random  : ${WHITE}$USER_RAND${NC}"
        echo -e " Password Random  : ${WHITE}$PASS_RAND${NC}"
        echo ""
        echo " [i] Save ini untuk login selanjutnya"
        line_sep
        sleep 3
    fi
    
    clear
    print_banner
    echo ""
    echo "------------------------------------>> Language <<----------------------------------------------"
    echo " Select Language / Pilih Bahasa"
    echo ""
    echo -e "   ${WHITE}[1]${NC} English"
    echo -e "   ${WHITE}[2]${NC} Indonesia"
    line_sep
    read -p " Choice / Pilihan [1/2] : " lang_choice
    case "$lang_choice" in
        2) echo "ind" > "$LANG_FILE" ;;
        *) echo "eng" > "$LANG_FILE" ;;
    esac
    ORAX_LANG=$(cat "$LANG_FILE")
    export ORAX_LANG
}

declare -a PLUGIN_FILES=()
declare -a PLUGIN_NAMES=()

load_plugins() {
    PLUGIN_FILES=()
    PLUGIN_NAMES=()
    for f in $(ls "$PLUGIN_DIR"/*.sh 2>/dev/null | sort); do
        PLUGIN_FILES+=("$f")
        local name=$(grep -m1 "^# NAME:" "$f" 2>/dev/null | sed 's/^# NAME:[[:space:]]*//')
        [ -z "$name" ] && name=$(basename "$f" .sh)
        PLUGIN_NAMES+=("$name")
    done
}

detect_network() {
    IFACE=$(ip route 2>/dev/null | grep default | awk '{print $5}' | head -n1)
    [ -z "$IFACE" ] && IFACE="wlan0"
    IP_ADDR=$(ifconfig "$IFACE" 2>/dev/null | grep -oP 'inet\s+\K[\d.]+' | head -n1)
    [ -z "$IP_ADDR" ] && IP_ADDR=$(ip addr show "$IFACE" 2>/dev/null | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | head -n1)
    SUBNET=$(echo "$IP_ADDR" | cut -d. -f1-3).0/24
    GATEWAY=$(ip route 2>/dev/null | grep default | awk '{print $3}' | head -n1)
    [ -z "$GATEWAY" ] && GATEWAY=$(echo "$IP_ADDR" | cut -d. -f1-3).1
}

show_info() {
    echo "------------------------------------>> OraxProject <<----------------------------------------------"
    echo -e " IP      : ${WHITE}$IP_ADDR${NC}"
    echo -e " Gateway : ${WHITE}$GATEWAY${NC}"
    echo -e " Subnet  : ${WHITE}$SUBNET${NC}"
    line_sep
    echo ""
}

# ===== STYLE 5: DOT MATRIX =====
NAME_W=22
COLS=4

pad_name() {
    local s="$1"
    local len=${#s}
    if [ "$len" -gt "$NAME_W" ]; then
        s="${s:0:$((NAME_W - 1))}."
        len=$NAME_W
    fi
    local pad=$((NAME_W - len))
    while [ "$pad" -gt 0 ]; do
        s="$s "
        ((pad--))
    done
    printf "%s" "$s"
}

render_menu_grid() {
    local selected=$1
    local total=${#PLUGIN_NAMES[@]}
    local i=0
    local cells_in_row=0

    echo ""

    for ((i=0; i<total; i++)); do
        local name="${PLUGIN_NAMES[$i]}"
        local padded=$(pad_name "$name")

        if [ "$i" -eq "$selected" ]; then
            printf "  ${WHITE}●●● %s${NC}" "$padded"
        else
            printf "  ${DIM}·· ${padded}${NC}"
        fi
        ((cells_in_row++))

        if [ "$cells_in_row" -eq "$COLS" ]; then
            echo ""
            cells_in_row=0
        fi
    done

    if [ "$cells_in_row" -gt 0 ]; then
        echo ""
    fi

    echo ""
    if [ "$selected" -eq "$total" ]; then
        echo -e "  ${WHITE}●●● $(t exit)${NC}"
    else
        echo -e "  ${DIM}··· $(t exit)${NC}"
    fi
    echo ""
    echo "  ${DIM}↑↓←→ Navigate   Enter Select   Ctrl+C Exit   • ${#PLUGIN_NAMES[@]} menus${NC}"
}

execute_plugin() {
    local idx=$1
    local total=${#PLUGIN_FILES[@]}
    [ "$idx" -ge "$total" ] && return 1
    local plugin_file="${PLUGIN_FILES[$idx]}"
    export ORAX_HOME PLUGIN_DIR RESULT_DIR ORAX_LANG
    export IP_ADDR GATEWAY SUBNET
    export WHITE GRAY DIM NC
    source "$plugin_file"
    return 0
}

main_loop() {
    local selected=0
    local total=${#PLUGIN_FILES[@]}
    local total_menu=$((total + 1))
    detect_network
    while true; do
        clear
        print_banner
        show_info
        render_menu_grid "$selected"
        echo ""
        IFS= read -rsn1 key
        if [[ "$key" == $'\x1b' ]]; then
            read -rsn2 -t 0.1 key
            case "$key" in
                '[A'|'[D') ((selected--)); [ "$selected" -lt 0 ] && selected=$((total_menu - 1)) ;;
                '[B'|'[C') ((selected++)); [ "$selected" -ge "$total_menu" ] && selected=0 ;;
            esac
        elif [[ "$key" == "" ]] || [[ "$key" == $'\x0f' ]]; then
            if ! execute_plugin "$selected"; then
                echo -e "\n${GRAY}[✓] $(t exit)${NC}\n"
                exit 0
            fi
        fi
    done
}

login_screen
load_plugins
trap "echo -e '\n${DIM}[!] $(t exit)...${NC}'; exit 0" INT
main_loop
